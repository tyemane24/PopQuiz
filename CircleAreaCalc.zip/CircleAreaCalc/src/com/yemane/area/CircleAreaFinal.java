package com.yemane.area;

public class CircleAreaFinal {

	static double pi = 3.14;
			static double radius = 5;
			static double area = 0;
			
	public static void main(String[] args) {

		calcAreaCircle(pi, radius);
		displayArea(area);
		
	}
public static void calcAreaCircle(double x, double n) {
	area = x * (n * n);
}
	public static void displayArea(double y) {
		System.out.println(y);
	}

}
